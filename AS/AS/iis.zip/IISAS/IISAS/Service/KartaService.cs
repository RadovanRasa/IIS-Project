﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IISAS.Service
{
    class KartaService : GenericService<Model.Karta>
    {
        public KartaService()
        {
            repository = new Repository.KartaRepository(@"C:\Users\pc\OneDrive\Radna površina\Radovan\IISBaza\Karta.txt");
        }
        public override int returnId(Model.Karta karta)
        {
            return karta.id_karte;
        }
        public override Model.Karta returnNULL()
        {
            return null;
        }
        public override void deleteOne(Model.Karta karta)
        {
            karta.obrisan = true;
        }
        public override void updateOne(Model.Karta karta, Model.Karta updatedKarta)
        {
            karta.broj_sedista = updatedKarta.broj_sedista;
            karta.cena = updatedKarta.cena;
            karta.vazeca = updatedKarta.vazeca;
            karta.voznja = updatedKarta.voznja;
            karta.vrsta_karte = updatedKarta.vrsta_karte;
        }
    }
}
