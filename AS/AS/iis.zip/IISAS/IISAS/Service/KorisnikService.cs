﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IISAS.Service
{
    class KorisnikService : GenericService<Model.Korisnik>
    {
        public KorisnikService()
        {
            repository = new Repository.KorisnikRepository(@"C:\Users\pc\OneDrive\Radna površina\Radovan\IISBaza\Korisnik.txt");
        }
        public override int returnId(Model.Korisnik korisnik)
        {
            return korisnik.id_kor;
        }
        public override Model.Korisnik returnNULL()
        {
            return null;
        }
        public override void deleteOne(Model.Korisnik korisnik)
        {
            korisnik.obrisan = true;
        }
        public override void updateOne(Model.Korisnik korisnik, Model.Korisnik updatedKorisnik)
        {
            korisnik.email = updatedKorisnik.email;
            korisnik.ime = updatedKorisnik.ime;
            korisnik.password = updatedKorisnik.password;
            korisnik.prezime = updatedKorisnik.prezime;
            korisnik.status_korisnika = updatedKorisnik.status_korisnika;
            korisnik.tip_korisnika = updatedKorisnik.tip_korisnika;
            korisnik.username = updatedKorisnik.username;
        }
    }
}
