﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace IISAS.xaml_window.korisnik_stan_usluga
{
    /// <summary>
    /// Interaction logic for Pregled_kupljenih_karata.xaml
    /// </summary>
    public partial class Pregled_kupljenih_karata : Window
    {
        public Pregled_kupljenih_karata()
        {
            InitializeComponent();
        }

        private void RedVoznje(object sender, RoutedEventArgs e)
        {
            var rv = new IISAS.xaml_window.korisnik_stan_usluga.Kupovina_karte();
            rv.Show();
            this.Close();
        }

        private void KupovinaKarte(object sender, RoutedEventArgs e)
        {
            var kk = new IISAS.xaml_window.korisnik_stan_usluga.Kupovina_karata_prava();
            kk.Show();
            this.Close();
        }

        private void Obrisi(object sender, RoutedEventArgs e)
        {

        }

        private void Detaljnije(object sender, RoutedEventArgs e)
        {
            var det = new IISAS.xaml_window.korisnik_stan_usluga.Pregled_kupljenih_karata_detaljnije();
            det.Show();
        }

        private void Oceni(object sender, RoutedEventArgs e)
        {
            var oc = new IISAS.xaml_window.korisnik_stan_usluga.Pregled_kupljenih_karata_ocena();
            oc.Show();
        }

        private void Korisnik_st_usluga_logout(object sender, RoutedEventArgs e)
        {
            var mn = new IISAS.MainWindow();
            mn.Show();
            this.Close();
        }
        private void tbSearch_LostFocus(object sender, RoutedEventArgs e)
        {
            tbPretraga.Foreground = new SolidColorBrush(Colors.Gray);
        }

        private void tbSearch_GotFocus(object sender, RoutedEventArgs e)
        {
            if (tbPretraga.Text == "Pretraga karata...")
            {
                tbPretraga.Clear();
            }
            tbPretraga.Foreground = new SolidColorBrush(Colors.Black);
        }

        private void tbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (tbPretraga.Text != "Pretraga karata...")
            {
                
            }
        }
    }
}
