﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace IISAS.xaml_window.admin
{
    /// <summary>
    /// Interaction logic for Upravljanje_statusima_korisnika_izmena.xaml
    /// </summary>
    public partial class Upravljanje_statusima_korisnika_izmena : Window
    {
        public Upravljanje_statusima_korisnika_izmena()
        {
            InitializeComponent();
        }

        private void Izmeni(object sender, RoutedEventArgs e)
        {

        }

        private void Izadji(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
