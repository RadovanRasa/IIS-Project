﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace IISAS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        xaml_window.korisnik_stan_usluga.Kupovina_karte red_voznje_window; 
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Korisnik_stanicnih_usluga(object sender, RoutedEventArgs e)
        {
            var redVoznje = new IISAS.xaml_window.korisnik_stan_usluga.Kupovina_karte();
            redVoznje.Show();
            this.Close();
        }

        private void Admin_AS(object sender, RoutedEventArgs e)
        {
            var aas = new IISAS.xaml_window.admin_as.Upravljanje_terminima();
            aas.Show();
            this.Close();
        }

        private void Prijava(object sender, RoutedEventArgs e)
        {
            var prijava = new IISAS.xaml_window.Login();
            prijava.Show();
            this.Close();
        }

        private void Admin(object sender, RoutedEventArgs e)
        {
            var admin = new IISAS.xaml_window.admin.Upravljanje_statusima_korisnika();
            admin.Show();
            this.Close();
        }
    }
}
