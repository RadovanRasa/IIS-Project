﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IISAS.Model
{
    public class Korisnik
    {
        public int id_kor;
        public String ime;
        public String prezime;
        public String tip_korisnika;
        public String status_korisnika;
        public String email;
        public String username;
        public String password;
        public bool obrisan;

        public Korisnik(int id_kor, String ime, String prezime, String tip_korisnika, 
            String status_korisnika,String email,String username,String password)
        {
            this.id_kor = id_kor;
            this.ime = ime;
            this.prezime = prezime;
            this.tip_korisnika = tip_korisnika;
            this.status_korisnika = status_korisnika;
            this.email = email;
            this.username = username;
            this.password = password;
            this.obrisan = false;
        }

    }
}
