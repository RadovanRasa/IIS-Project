﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IISAS.Model
{
    public class Karta
    {
        public int id_karte;
        public Voznja voznja;
        //Ovde dodati korisniika
        public int broj_sedista;
        public int cena;
        public String vrsta_karte;
        public String vazeca;
        public bool obrisan;

        public Karta(int id_karte, int voznjaId, int broj_sedista, int cena, String vrsta_karte, String vazeca)
        {
            Service.VoznjaService voznjaService = new Service.VoznjaService();

            this.id_karte = id_karte;
            this.voznja = voznjaService.GetOne(voznjaId);
            this.broj_sedista = broj_sedista;
            this.cena = cena;
            this.vrsta_karte = vrsta_karte;
            this.vazeca = vazeca;
            this.obrisan = false;
        }
    }
}
